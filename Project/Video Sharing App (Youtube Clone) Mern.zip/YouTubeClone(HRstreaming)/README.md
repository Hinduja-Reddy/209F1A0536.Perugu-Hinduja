# Video-Sharing-app-MERN
Demo - <a href="https://drive.google.com/file/d/1_2Dz5gVzC8HlJ3HNsG1JJP2Ktm5Rge72/view?usp=sharing">view video</a>
